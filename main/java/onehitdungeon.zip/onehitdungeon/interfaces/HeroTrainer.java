package onehitdungeon.interfaces;

public interface HeroTrainer {
    void trainHero(Hero hero);
}
