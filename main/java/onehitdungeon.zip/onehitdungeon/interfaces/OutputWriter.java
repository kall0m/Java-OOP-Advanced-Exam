package onehitdungeon.interfaces;

public interface OutputWriter {
    void print(String output);

    void println(String output);
}
