package onehitdungeon.constants;

public final class ClassesReferences {
    private ClassesReferences() {}

    public final static String HEROES_REFERENCE = "onehitdungeon.domain.heroes.";
}
